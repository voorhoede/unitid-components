To get this page working on the live site some assets urls have been changed. 
Need to check this with Anne@voorhoede.nl.
