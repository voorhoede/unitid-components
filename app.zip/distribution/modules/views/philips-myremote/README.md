<!--
Add an optional short description here for `Philips-myremote` view.
Or delete this file if not applicable.
-->