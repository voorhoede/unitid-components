The component-previewer view is used in the `grunt compile-previews` task
to compile a preview page for each component.